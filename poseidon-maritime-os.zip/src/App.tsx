import React, { useState, useEffect, useMemo } from 'react';
import { 
  Ship, 
  Activity, 
  ShieldCheck, 
  Navigation, 
  Settings, 
  AlertTriangle, 
  BarChart3, 
  Cpu, 
  Globe, 
  Wind, 
  Thermometer, 
  Fuel,
  ChevronRight,
  Search,
  Bell,
  Layers,
  Zap
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { Vessel, MicroserviceStatus } from './types';
import { MOCK_VESSELS, MOCK_SERVICES, DOMAINS } from './mockData';

// --- Components ---

function StatusBadge({ status }: { status: MicroserviceStatus['status'] }) {
  const colors = {
    healthy: 'bg-accent',
    degraded: 'bg-warning',
    down: 'bg-danger'
  };
  const glow = {
    healthy: 'status-glow-healthy',
    degraded: 'status-glow-degraded',
    down: 'status-glow-down'
  };

  return (
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${colors[status]} ${glow[status]}`} />
      <span className="text-[10px] uppercase tracking-wider font-mono opacity-80">{status}</span>
    </div>
  );
}

function MetricCard({ label, value, unit, icon: Icon, trend, subValue, extra }: any) {
  return (
    <div className="glass-panel p-4 rounded-xl flex flex-col gap-1 relative overflow-hidden">
      <div className="flex justify-between items-start">
        <div className="p-2 bg-white/5 rounded-lg">
          <Icon size={16} className="text-accent" />
        </div>
        {trend && (
          <span className={`text-[10px] font-mono ${trend > 0 ? 'text-accent' : 'text-danger'}`}>
            {trend > 0 ? '+' : ''}{trend}%
          </span>
        )}
        {extra}
      </div>
      <span className="text-text-dim text-[11px] uppercase tracking-wider font-medium mt-2">{label}</span>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-display font-bold">{value}</span>
        <span className="text-text-dim text-xs font-mono">{unit}</span>
      </div>
      {subValue && (
        <span className="text-[10px] font-mono text-text-dim mt-1">{subValue}</span>
      )}
    </div>
  );
}

function MicroserviceItem({ service }: { service: MicroserviceStatus }) {
  return (
    <div className="flex items-center justify-between p-3 hover:bg-white/5 rounded-lg transition-colors border-b border-white/5 last:border-0">
      <div className="flex flex-col">
        <span className="text-sm font-medium">{service.name}</span>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-[10px] font-mono px-1.5 py-0.5 bg-white/10 rounded text-text-dim">{service.language}</span>
          <span className="text-[10px] text-text-dim font-mono">{service.latency}ms</span>
        </div>
      </div>
      <StatusBadge status={service.status} />
    </div>
  );
}

// --- Main App ---

export default function App() {
  const [selectedVessel, setSelectedVessel] = useState<Vessel>(MOCK_VESSELS[0]);
  const [activeDomain, setActiveDomain] = useState('Fleet Operations');
  const [telemetryData, setTelemetryData] = useState<any[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [wind, setWind] = useState<{ speed: number; direction: number; gusts?: number } | null>(null);
  const [windError, setWindError] = useState<string | null>(null);

  // Fetch real-time wind data
  useEffect(() => {
    const fetchWind = async () => {
      setWindError(null);
      try {
        const response = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${selectedVessel.lat}&longitude=${selectedVessel.lng}&current=wind_speed_10m,wind_direction_10m,wind_gusts_10m`
        );
        if (!response.ok) {
          throw new Error(`Weather API error: ${response.status}`);
        }
        const data = await response.json();
        if (data.current) {
          setWind({
            speed: data.current.wind_speed_10m,
            direction: data.current.wind_direction_10m,
            gusts: data.current.wind_gusts_10m,
          });
        } else {
          throw new Error('Invalid weather data format');
        }
      } catch (error) {
        console.error('Failed to fetch wind data:', error);
        setWindError('Weather data unavailable');
      }
    };

    fetchWind();
    const interval = setInterval(fetchWind, 60000); // Update every minute
    return () => clearInterval(interval);
  }, [selectedVessel.lat, selectedVessel.lng]);

  // Simulate real-time telemetry
  useEffect(() => {
    const generateData = () => {
      const data = [];
      for (let i = 0; i < 20; i++) {
        data.push({
          time: i + ':00',
          temp: 70 + Math.random() * 20,
          fuel: 80 - i * 0.5 + Math.random() * 2,
          speed: 15 + Math.random() * 5
        });
      }
      setTelemetryData(data);
    };
    generateData();

    const timer = setInterval(() => {
      setCurrentTime(new Date());
      setTelemetryData(prev => {
        const last = prev[prev.length - 1];
        const nextTime = (parseInt(last.time) + 1) % 24 + ':00';
        return [...prev.slice(1), {
          time: nextTime,
          temp: 70 + Math.random() * 20,
          fuel: Math.max(0, last.fuel - 0.1 + (Math.random() - 0.5)),
          speed: 15 + Math.random() * 5
        }];
      });
    }, 3000);

    return () => clearInterval(timer);
  }, []);

  const filteredServices = useMemo(() => 
    MOCK_SERVICES.filter(s => s.domain === activeDomain), 
  [activeDomain]);

  return (
    <div className="flex h-screen w-full technical-grid">
      {/* Sidebar */}
      <aside className="w-64 glass-panel border-r border-white/10 flex flex-col z-20">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center status-glow-healthy">
            <Ship size={24} className="text-black" />
          </div>
          <div className="flex flex-col">
            <h1 className="font-display font-bold text-lg leading-tight">POSEIDON</h1>
            <span className="text-[10px] text-accent font-mono tracking-[0.2em] uppercase">Maritime OS</span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          <div className="text-[10px] text-text-dim font-mono uppercase tracking-widest px-2 mb-4">Domains</div>
          {DOMAINS.map(domain => (
            <button
              key={domain}
              onClick={() => setActiveDomain(domain)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm font-medium ${
                activeDomain === domain 
                  ? 'bg-accent/10 text-accent border border-accent/20' 
                  : 'text-text-dim hover:bg-white/5 hover:text-white'
              }`}
            >
              {domain === 'Fleet Operations' && <Ship size={16} />}
              {domain === 'Port & Logistics' && <Layers size={16} />}
              {domain === 'Passenger & Crew' && <Globe size={16} />}
              {domain === 'Safety & Compliance' && <ShieldCheck size={16} />}
              {domain === 'Navigation & IoT' && <Navigation size={16} />}
              {domain === 'Business Support' && <BarChart3 size={16} />}
              {domain === 'Infrastructure' && <Settings size={16} />}
              {domain === 'Integration' && <Zap size={16} />}
              <span className="truncate">{domain}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <div className="glass-panel rounded-xl p-3 bg-white/5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-mono text-text-dim uppercase">System Health</span>
              <span className="text-[10px] font-mono text-accent">98.2%</span>
            </div>
            <div className="h-1 bg-white/10 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: '98.2%' }}
                className="h-full bg-accent"
              />
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 glass-panel border-b border-white/10 flex items-center justify-between px-8 z-10">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-text-dim">
              <Globe size={14} />
              <span className="text-xs font-mono">UTC {currentTime.toLocaleTimeString()}</span>
            </div>
            <div className="h-4 w-[1px] bg-white/10" />
            <div className="flex items-center gap-2 text-accent">
              <Activity size={14} />
              <span className="text-xs font-mono uppercase tracking-wider">Live Telemetry Active</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-dim" size={14} />
              <input 
                type="text" 
                placeholder="Search fleet..." 
                className="bg-white/5 border border-white/10 rounded-full py-1.5 pl-9 pr-4 text-xs focus:outline-none focus:border-accent/50 w-64 transition-all"
              />
            </div>
            <button className="p-2 hover:bg-white/5 rounded-full text-text-dim relative">
              <Bell size={18} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-danger rounded-full border-2 border-[#0a0b0d]" />
            </button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent to-blue-500 border border-white/20" />
          </div>
        </header>

        {/* Dashboard Body */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          {/* Top Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            <MetricCard label="Active Vessels" value="1,042" unit="Units" icon={Ship} trend={2.4} />
            <MetricCard label="Avg. Fleet Speed" value="16.4" unit="Knots" icon={Navigation} trend={-0.8} />
            <MetricCard label="Fuel Efficiency" value="94.2" unit="%" icon={Fuel} trend={1.2} />
            <MetricCard 
              label="Wind Conditions" 
              value={windError ? 'Error' : (wind ? wind.speed.toFixed(1) : '--')} 
              unit={windError ? '' : 'km/h'} 
              icon={Wind} 
              subValue={windError ? windError : (wind ? `Dir: ${wind.direction}° | Gusts: ${wind.gusts?.toFixed(1) ?? '--'} km/h` : undefined)}
              extra={wind && !windError && (
                <div className="flex flex-col items-center gap-1">
                  <div className="relative w-8 h-8 flex items-center justify-center border border-white/10 rounded-full bg-white/5">
                    <span className="absolute -top-1 text-[6px] font-mono text-text-dim">N</span>
                    <motion.div 
                      animate={{ rotate: wind.direction }}
                      transition={{ type: 'spring', stiffness: 50, damping: 15 }}
                      className="text-accent"
                    >
                      <Navigation size={14} style={{ transform: 'rotate(-45deg)' }} />
                    </motion.div>
                  </div>
                </div>
              )}
            />
            <MetricCard label="Safety Alerts" value="0" unit="Active" icon={ShieldCheck} />
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            {/* Map / Fleet View */}
            <div className="xl:col-span-2 flex flex-col gap-6">
              <div className="glass-panel rounded-2xl p-6 flex flex-col h-[500px]">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex flex-col">
                    <h2 className="text-lg font-display font-bold">Fleet Distribution</h2>
                    <span className="text-xs text-text-dim">Real-time geospatial tracking across 1,000+ services</span>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-3 py-1.5 bg-white/5 rounded-lg text-xs font-medium hover:bg-white/10 transition-colors">Satellite</button>
                    <button className="px-3 py-1.5 bg-accent/20 text-accent rounded-lg text-xs font-medium border border-accent/20">Vector</button>
                  </div>
                </div>
                
                {/* Stylized Map Placeholder */}
                <div className="flex-1 bg-[#0d0e12] rounded-xl relative overflow-hidden border border-white/5 technical-grid">
                  {/* Simulated Map Markers */}
                  {MOCK_VESSELS.map((vessel) => (
                    <motion.div
                      key={vessel.id}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      whileHover={{ scale: 1.2 }}
                      onClick={() => setSelectedVessel(vessel)}
                      className={`absolute cursor-pointer p-1 rounded-full transition-all ${
                        selectedVessel.id === vessel.id ? 'bg-accent z-10' : 'bg-white/20'
                      }`}
                      style={{ 
                        left: `${(vessel.lng + 180) / 3.6}%`, 
                        top: `${(90 - vessel.lat) / 1.8}%` 
                      }}
                    >
                      <div className={`w-3 h-3 rounded-full ${selectedVessel.id === vessel.id ? 'bg-black' : 'bg-accent'}`} />
                      {selectedVessel.id === vessel.id && (
                        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-panel border border-white/10 p-2 rounded shadow-2xl whitespace-nowrap">
                          <span className="text-[10px] font-bold block">{vessel.name}</span>
                          <span className="text-[8px] text-text-dim block">{vessel.status} • {vessel.speed} kts</span>
                        </div>
                      )}
                    </motion.div>
                  ))}

                  {/* Scan Line Animation */}
                  <motion.div 
                    animate={{ top: ['0%', '100%'] }}
                    transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
                    className="absolute left-0 right-0 h-[2px] bg-accent/20 blur-[1px] z-0"
                  />
                </div>
              </div>

              {/* Telemetry Charts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass-panel rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Thermometer size={16} className="text-warning" />
                      <h3 className="text-sm font-bold">Engine Temperature</h3>
                    </div>
                    <span className="text-[10px] font-mono text-text-dim">Vessel: {selectedVessel.id}</span>
                  </div>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={telemetryData}>
                        <defs>
                          <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#ffcc00" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#ffcc00" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                        <XAxis dataKey="time" hide />
                        <YAxis hide domain={[0, 120]} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#151619', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                          itemStyle={{ color: '#ffcc00', fontSize: '12px' }}
                        />
                        <Area type="monotone" dataKey="temp" stroke="#ffcc00" fillOpacity={1} fill="url(#colorTemp)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="glass-panel rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Fuel size={16} className="text-accent" />
                      <h3 className="text-sm font-bold">Fuel Consumption</h3>
                    </div>
                    <span className="text-[10px] font-mono text-text-dim">Vessel: {selectedVessel.id}</span>
                  </div>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={telemetryData}>
                        <defs>
                          <linearGradient id="colorFuel" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#00ff9d" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#00ff9d" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                        <XAxis dataKey="time" hide />
                        <YAxis hide domain={[0, 100]} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#151619', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                          itemStyle={{ color: '#00ff9d', fontSize: '12px' }}
                        />
                        <Area type="monotone" dataKey="fuel" stroke="#00ff9d" fillOpacity={1} fill="url(#colorFuel)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar Widgets */}
            <div className="flex flex-col gap-8">
              {/* Domain Services */}
              <div className="glass-panel rounded-2xl flex flex-col overflow-hidden">
                <div className="p-6 border-b border-white/5">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold flex items-center gap-2">
                      <Cpu size={18} className="text-accent" />
                      {activeDomain}
                    </h3>
                    <span className="text-[10px] font-mono bg-white/5 px-2 py-1 rounded">{filteredServices.length} Services</span>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto max-h-[400px]">
                  {filteredServices.map(service => (
                    <div key={service.id}>
                      <MicroserviceItem service={service} />
                    </div>
                  ))}
                </div>
                <button className="p-4 text-xs text-text-dim hover:text-white transition-colors flex items-center justify-center gap-2 border-t border-white/5">
                  View All Domain Services <ChevronRight size={14} />
                </button>
              </div>

              {/* Selected Vessel Detail */}
              <div className="glass-panel rounded-2xl p-6 flex flex-col gap-6">
                <div className="flex items-start justify-between">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-mono text-text-dim uppercase tracking-widest">Selected Vessel</span>
                    <h3 className="text-xl font-display font-bold">{selectedVessel.name}</h3>
                  </div>
                  <div className="px-2 py-1 bg-accent/10 text-accent text-[10px] font-mono rounded border border-accent/20">
                    {selectedVessel.id}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col p-3 bg-white/5 rounded-xl">
                    <span className="text-[10px] text-text-dim uppercase font-mono">Status</span>
                    <span className="text-sm font-medium">{selectedVessel.status}</span>
                  </div>
                  <div className="flex flex-col p-3 bg-white/5 rounded-xl">
                    <span className="text-[10px] text-text-dim uppercase font-mono">Type</span>
                    <span className="text-sm font-medium">{selectedVessel.type}</span>
                  </div>
                  <div className="flex flex-col p-3 bg-white/5 rounded-xl">
                    <span className="text-[10px] text-text-dim uppercase font-mono">Speed</span>
                    <span className="text-sm font-medium">{selectedVessel.speed} kts</span>
                  </div>
                  <div className="flex flex-col p-3 bg-white/5 rounded-xl">
                    <span className="text-[10px] text-text-dim uppercase font-mono">Heading</span>
                    <span className="text-sm font-medium">{selectedVessel.heading}°</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-[10px] font-mono uppercase">
                      <span className="text-text-dim">Fuel Level</span>
                      <span className={selectedVessel.fuelLevel < 20 ? 'text-danger' : 'text-accent'}>{selectedVessel.fuelLevel}%</span>
                    </div>
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${selectedVessel.fuelLevel}%` }}
                        className={`h-full ${selectedVessel.fuelLevel < 20 ? 'bg-danger' : 'bg-accent'}`}
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-[10px] font-mono uppercase">
                      <span className="text-text-dim">Engine Load</span>
                      <span className="text-warning">64%</span>
                    </div>
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: '64%' }}
                        className="h-full bg-warning"
                      />
                    </div>
                  </div>
                </div>

                <button className="w-full py-3 bg-accent text-black rounded-xl font-bold text-sm hover:bg-accent/90 transition-all flex items-center justify-center gap-2">
                  <Settings size={16} />
                  Open Control Interface
                </button>
              </div>

              {/* Alerts */}
              <div className="glass-panel rounded-2xl p-6 border-l-4 border-warning">
                <div className="flex items-center gap-3 mb-2">
                  <AlertTriangle className="text-warning" size={20} />
                  <h3 className="font-bold text-sm">Active Maintenance Alert</h3>
                </div>
                <p className="text-xs text-text-dim leading-relaxed">
                  Vessel <span className="text-white font-mono">V-104</span> (Northern Star) engine diagnostic service reports abnormal vibration in Cylinder 4.
                </p>
                <div className="mt-4 flex gap-2">
                  <button className="flex-1 py-2 bg-white/10 rounded-lg text-[10px] font-bold uppercase hover:bg-white/20 transition-all">Dismiss</button>
                  <button className="flex-1 py-2 bg-warning text-black rounded-lg text-[10px] font-bold uppercase hover:bg-warning/90 transition-all">Investigate</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
