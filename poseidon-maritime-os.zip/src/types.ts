export interface Vessel {
  id: string;
  name: string;
  type: 'Cargo' | 'Tanker' | 'Passenger' | 'Tug';
  status: 'Underway' | 'Moored' | 'At Anchor' | 'Maintenance';
  lat: number;
  lng: number;
  speed: number;
  heading: number;
  fuelLevel: number;
  engineTemp: number;
  lastUpdate: string;
}

export interface MicroserviceStatus {
  id: string;
  name: string;
  domain: string;
  status: 'healthy' | 'degraded' | 'down';
  latency: number;
  language: string;
}

export interface TelemetryPoint {
  time: string;
  value: number;
}
